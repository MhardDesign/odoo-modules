Print Work Order Details
========================
Generate PDF Report of Work Order

Depends
=======
[mrp] addon Odoo

Installation
============
- www.odoo.com/documentation/15.0/setup/install.html
- Install our custom addon

License
=======
GNU AFFERO GENERAL PUBLIC LICENSE, Version 3 (AGPLv3)
(http://www.gnu.org/licenses/agpl.html)

Bug Tracker
===========
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Authors
-------
* Faslu <odoo@cybrosys.com>

Credits
-------
* Developers: Faslu @cybrosys
              Version 14: Minhaj T @cybrosys
              Version 15: Sagarika B @cybrosys

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.
