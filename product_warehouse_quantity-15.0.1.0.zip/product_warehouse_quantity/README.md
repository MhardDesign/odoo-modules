Quick access of quantity available in each warehouse
----------------------------------------------------

This module is a step forward to allow the user to have access to analysed information quickly.
This module helps specifically for multi warehouse structure, to find the number of quantity available in each of the warehouse.
The warehoue has the one stock location.
There may be various child location of each of that stok location. Each of such location may have some quantity of the product.
This module shows the cumulative sum of total quantity available in each varehosue and shows on the product form view and kanban view.
